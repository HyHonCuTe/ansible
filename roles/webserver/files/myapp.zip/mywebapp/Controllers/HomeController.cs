﻿using Microsoft.AspNetCore.Mvc;
using demoAN.Models;
using System.Linq;

namespace demoAN.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        // Hiển thị danh sách tên khi GET
        [HttpGet]
        public IActionResult Index()
        {
            var danhSach = _context.Person.Select(p => p.Name).ToList();
            ViewBag.DanhSachTen = danhSach;
            return View();
        }

        // Lưu tên mới vào DB khi POST
        [HttpPost]
        public IActionResult Index(string ten)
        {
            if (!string.IsNullOrEmpty(ten))
            {
                _context.Person.Add(new Person { Name = ten });
                _context.SaveChanges();
                ViewBag.Message = "Đã lưu thành công!";
            }
            else
            {
                ViewBag.Message = "Tên không được để trống.";
            }

            // Cập nhật danh sách tên
            var danhSach = _context.Person.Select(p => p.Name).ToList();
            ViewBag.DanhSachTen = danhSach;
            return View();
        }
    }
}
