using Microsoft.EntityFrameworkCore;

namespace NameListWeb.Models
{
    public class NameDbContext : DbContext
    {
        public NameDbContext(DbContextOptions<NameDbContext> options) : base(options) { }

        public DbSet<Person> People { get; set; }
    }
}