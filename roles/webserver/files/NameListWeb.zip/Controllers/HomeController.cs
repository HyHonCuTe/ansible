using Microsoft.AspNetCore.Mvc;
using NameListWeb.Models;
using System.Linq;

namespace NameListWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly NameDbContext _context;

        public HomeController(NameDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var names = _context.People.ToList();
            return View(names);
        }

        [HttpPost]
        public IActionResult Add(string name)
        {
            _context.People.Add(new Person { Name = name });
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}