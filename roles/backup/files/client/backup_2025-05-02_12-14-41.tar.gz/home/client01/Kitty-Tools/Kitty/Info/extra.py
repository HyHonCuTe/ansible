import os
import platform
import sys
from scripts.sprint import sprint
from scripts.colors import ran,y,r,g,c
import time
sprint(f"{y}Your a poopie head <3")
time.sleep(5)

from subprocess import call
call(["python", "main.py"])
