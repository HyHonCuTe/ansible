This directory is were all of the magic happens... this is were all of the main scripts for the CTI are
