import os
from os import system

def try_install(str):
    os.system("pip install colorama") #required
    os.system("pip install pystyle") #required
